import { SocialMediaPlatformType } from "./types";

export const APP_NAME = "حسابات الحمزاوي";

export const GEMINI_TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';

export const EXPENSE_CATEGORIES = [
  "Raw Materials",
  "Utilities",
  "Maintenance",
  "Salaries & Wages", // e.g. contractor payments, not direct employee payroll
  "Rent",
  "Factory Supplies",
  "Office Supplies",
  "Transportation & Logistics",
  "Marketing & Advertising",
  "Repairs",
  "Software & Subscriptions",
  "Other",
] as const;

export type ExpenseCategoryKey = typeof EXPENSE_CATEGORIES[number];

export const EXPENSE_CATEGORY_TRANSLATIONS: Record<ExpenseCategoryKey, string> = {
  "Raw Materials": "مواد خام",
  "Utilities": "خدمات (كهرباء، ماء)",
  "Maintenance": "صيانة",
  "Salaries & Wages": "رواتب وأجور (غير مباشرة)",
  "Rent": "إيجار",
  "Factory Supplies": "مستلزمات المصنع",
  "Office Supplies": "أدوات مكتبية",
  "Transportation & Logistics": "نقل ولوجستيات",
  "Marketing & Advertising": "تسويق وإعلان",
  "Repairs": "إصلاحات",
  "Software & Subscriptions": "برامج واشتراكات",
  "Other": "أخرى",
};

export const SOCIAL_MEDIA_PLATFORMS = ["Facebook", "Instagram", "WhatsApp", "X (Twitter)", "TikTok", "Other"] as const;

export const SOCIAL_MEDIA_PLATFORM_TRANSLATIONS: Record<SocialMediaPlatformType, string> = {
  "Facebook": "فيسبوك",
  "Instagram": "إنستغرام",
  "WhatsApp": "واتساب",
  "X (Twitter)": "إكس (تويتر سابقًا)",
  "TikTok": "تيك توك",
  "Other": "أخرى",
};

export const LOCAL_STORAGE_KEYS = {
  EMPLOYEES: 'factoryLedgerAI_employees',
  EXPENSES: 'factoryLedgerAI_expenses',
  INVENTORY_ITEMS: 'factoryLedgerAI_inventoryItems',
  SUPPLIERS: 'factoryLedgerAI_suppliers', // Our suppliers
  RETAIL_SALES: 'factoryLedgerAI_retailSales',
  SOCIAL_MEDIA_SALES: 'factoryLedgerAI_socialMediaSales',
  SALES_TO_CLIENT_SUPPLIERS: 'factoryLedgerAI_salesToClientSuppliers',
  SALES_TO_CLIENT_TRADERS: 'factoryLedgerAI_salesToClientTraders',
};

export const API_KEY_MESSAGE = "مفتاح Gemini API (process.env.API_KEY) غير مُكوّن. ستكون ميزات الذكاء الاصطناعي محدودة.";

export const TRANSLATIONS = {
  ourUnitCost: "التكلفة الأصلية للمنتج (علينا)",
  sellingPriceToCustomer: "سعر البيع للعميل",
  profitForItem: "المكسب من هذا الصنف",
  totalCostOfGoods: "إجمالي تكلفة البضاعة",
  totalRevenue: "إجمالي سعر البيع (الإيرادات)",
  totalProfit: "إجمالي المكسب (الربح)",
  quantityOrdered: "الكمية المطلوبة",
  addItemToInvoice: "إضافة الصنف للفاتورة",
  completeItemDetailsCorrectly: "الرجاء إكمال بيانات الصنف الحالي (الاسم، الكمية، التكلفة علينا، سعر البيع) بشكل صحيح.",
  addAtLeastOneItem: "الرجاء إضافة صنف واحد على الأقل لعملية البيع.",
  salesToClientSuppliers: "مبيعات للعملاء الموردين",
  salesToClientTraders: "مبيعات للعملاء التجار",
  clientSupplierName: "اسم العميل المورد",
  clientTraderName: "اسم العميل التاجر",
  addNewSaleToClientSupplier: "تسجيل عملية بيع لعميل مورد",
  editSaleToClientSupplier: "تعديل بيانات بيع لعميل مورد",
  addNewSaleToClientTrader: "تسجيل عملية بيع لعميل تاجر",
  editSaleToClientTrader: "تعديل بيانات بيع لعميل تاجر",
  noSalesToClientSuppliers: "لا توجد مبيعات لعملاء موردين مسجلة.",
  noSalesToClientTraders: "لا توجد مبيعات لعملاء تجار مسجلة.",
  confirmDeleteSale: "هل أنت متأكد أنك تريد حذف عملية البيع هذه؟",
  totalItems: "عدد الأصناف",
  printInvoice: "طباعة الفاتورة",
  invoiceTitleRetail: "فاتورة بيع بالتجزئة",
  invoiceTitleSocialMedia: "فاتورة بيع سوشيال ميديا",
  invoiceTitleClientSupplier: "فاتورة بيع لعميل مورد",
  invoiceTitleClientTrader: "فاتورة بيع لعميل تاجر",
  invoiceId: "رقم الفاتورة",
  invoiceDate: "تاريخ الفاتورة",
  customerInfo: "بيانات العميل",
  platform: "المنصة",
  customerIdentifier: "معرف العميل",
  shippingAddress: "عنوان الشحن",
  productName: "اسم المنتج/الصنف",
  quantity: "الكمية",
  unitCostAtSale: "تكلفة الوحدة (علينا)",
  sellingPrice: "سعر بيع الوحدة",
  itemTotal: "إجمالي الصنف",
  itemProfit: "ربح الصنف",
  notes: "ملاحظات",
  appCreatorCredit: "تطوير:",
  appCreatorName: "Farouk AD Golden",
  thankYouNote: "شكراً لتعاملكم معنا!",
};

import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { Expense } from '../types';
import ExpenseForm from '../components/ExpenseForm';
import ExpenseTable from '../components/ExpenseTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS, API_KEY_MESSAGE } from '../constants';
import { isGeminiAvailable } from '../services/geminiService';


const ExpensesPage: React.FC = () => {
  const [expenses, setExpenses] = useLocalStorage<Expense[]>(LOCAL_STORAGE_KEYS.EXPENSES, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingExpense, setEditingExpense] = useState<Expense | null>(null);
  const geminiAvailable = isGeminiAvailable();

  const handleAddExpense = (expenseData: Omit<Expense, 'id'>) => {
    const newExpense: Expense = {
      ...expenseData,
      id: Date.now().toString(), // Simple ID generation
    };
    setExpenses([...expenses, newExpense].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setIsModalOpen(false);
  };

  const handleEditExpense = (expenseData: Omit<Expense, 'id'>) => {
    if (!editingExpense) return;
    setExpenses(
      expenses.map((exp) =>
        exp.id === editingExpense.id ? { ...exp, ...expenseData } : exp
      ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    );
    setEditingExpense(null);
    setIsModalOpen(false);
  };

  const openEditModal = (expense: Expense) => {
    setEditingExpense(expense);
    setIsModalOpen(true);
  };

  const handleDeleteExpense = (expenseId: string) => {
    if (window.confirm('هل أنت متأكد أنك تريد حذف هذا المصروف؟')) {
        setExpenses(expenses.filter(exp => exp.id !== expenseId));
    }
  };

  const openAddModal = () => {
    setEditingExpense(null);
    setIsModalOpen(true);
  };
  
  return (
    <div>
      <PageTitle title="إدارة المصروفات">
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-dark focus:ring-opacity-50"
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>تسجيل مصروف</span>
        </button>
      </PageTitle>

      {!geminiAvailable && (
        <div className="mb-4 p-3 bg-yellow-100 ltr:border-l-4 rtl:border-r-4 border-yellow-500 text-yellow-700 rounded-md">
            <p>{API_KEY_MESSAGE} سيكون اقتراح الفئة محدودًا.</p>
        </div>
      )}

      <ExpenseTable expenses={expenses} onEdit={openEditModal} onDelete={handleDeleteExpense} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingExpense(null);
        }}
        title={editingExpense ? 'تعديل المصروف' : 'تسجيل مصروف جديد'}
      >
        <ExpenseForm
          onSubmit={editingExpense ? handleEditExpense : handleAddExpense}
          onClose={() => {
            setIsModalOpen(false);
            setEditingExpense(null);
          }}
          initialData={editingExpense}
        />
      </Modal>
    </div>
  );
};

export default ExpensesPage;
import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { SaleToClientTrader } from '../types';
import SalesToClientTraderForm from '../components/SalesToClientTraderForm';
import SalesToClientTraderTable from '../components/SalesToClientTraderTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS, TRANSLATIONS } from '../constants';

const SalesToClientTradersPage: React.FC = () => {
  const [sales, setSales] = useLocalStorage<SaleToClientTrader[]>(LOCAL_STORAGE_KEYS.SALES_TO_CLIENT_TRADERS, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<SaleToClientTrader | null>(null);

  const handleAddSale = (saleData: Omit<SaleToClientTrader, 'id'>) => {
    const newSale: SaleToClientTrader = {
      ...saleData,
      id: Date.now().toString(),
    };
    setSales([...sales, newSale].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setIsModalOpen(false);
  };

  const handleEditSale = (saleData: Omit<SaleToClientTrader, 'id'>) => {
    if (!editingSale) return;
    setSales(
      sales.map((s) =>
        s.id === editingSale.id ? { id: s.id, ...saleData } : s
      ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    );
    setEditingSale(null);
    setIsModalOpen(false);
  };

  const openEditModal = (sale: SaleToClientTrader) => {
    setEditingSale(sale);
    setIsModalOpen(true);
  };
  
  const handleDeleteSale = (saleId: string) => {
    if (window.confirm(TRANSLATIONS.confirmDeleteSale)) {
        setSales(sales.filter(s => s.id !== saleId));
    }
  };

  const openAddModal = () => {
    setEditingSale(null);
    setIsModalOpen(true);
  };

  return (
    <div>
      <PageTitle title={TRANSLATIONS.salesToClientTraders}>
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors"
          aria-label={TRANSLATIONS.addNewSaleToClientTrader}
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>{TRANSLATIONS.addNewSaleToClientTrader}</span>
        </button>
      </PageTitle>

      <SalesToClientTraderTable sales={sales} onEdit={openEditModal} onDelete={handleDeleteSale} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingSale(null);
        }}
        title={editingSale ? TRANSLATIONS.editSaleToClientTrader : TRANSLATIONS.addNewSaleToClientTrader}
      >
        <SalesToClientTraderForm
          onSubmit={editingSale ? handleEditSale : handleAddSale}
          onClose={() => {
            setIsModalOpen(false);
            setEditingSale(null);
          }}
          initialData={editingSale}
        />
      </Modal>
    </div>
  );
};

export default SalesToClientTradersPage;

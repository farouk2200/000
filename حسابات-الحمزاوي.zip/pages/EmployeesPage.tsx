
import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { Employee } from '../types';
import EmployeeForm from '../components/EmployeeForm';
import EmployeeTable from '../components/EmployeeTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS } from '../constants';

const EmployeesPage: React.FC = () => {
  const [employees, setEmployees] = useLocalStorage<Employee[]>(LOCAL_STORAGE_KEYS.EMPLOYEES, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmployee, setEditingEmployee] = useState<Employee | null>(null);

  const handleAddEmployee = (employeeData: Omit<Employee, 'id'>) => {
    const newEmployee: Employee = {
      ...employeeData,
      id: Date.now().toString(), // Simple ID generation
    };
    setEmployees([...employees, newEmployee]);
    setIsModalOpen(false);
  };

  const handleEditEmployee = (employeeData: Omit<Employee, 'id'>) => {
    if (!editingEmployee) return;
    setEmployees(
      employees.map((emp) =>
        emp.id === editingEmployee.id ? { ...emp, ...employeeData } : emp
      )
    );
    setEditingEmployee(null);
    setIsModalOpen(false);
  };

  const openEditModal = (employee: Employee) => {
    setEditingEmployee(employee);
    setIsModalOpen(true);
  };
  
  const handleDeleteEmployee = (employeeId: string) => {
    if (window.confirm('هل أنت متأكد أنك تريد حذف هذا الموظف؟')) {
        setEmployees(employees.filter(emp => emp.id !== employeeId));
    }
  };

  const openAddModal = () => {
    setEditingEmployee(null);
    setIsModalOpen(true);
  };

  return (
    <div>
      <PageTitle title="إدارة الموظفين">
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-dark focus:ring-opacity-50"
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>إضافة موظف</span>
        </button>
      </PageTitle>

      <EmployeeTable employees={employees} onEdit={openEditModal} onDelete={handleDeleteEmployee} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingEmployee(null);
        }}
        title={editingEmployee ? 'تعديل بيانات الموظف' : 'إضافة موظف جديد'}
      >
        <EmployeeForm
          onSubmit={editingEmployee ? handleEditEmployee : handleAddEmployee}
          onClose={() => {
            setIsModalOpen(false);
            setEditingEmployee(null);
          }}
          initialData={editingEmployee}
        />
      </Modal>
    </div>
  );
};

export default EmployeesPage;
import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { SaleToClientSupplier } from '../types';
import SalesToClientSupplierForm from '../components/SalesToClientSupplierForm';
import SalesToClientSupplierTable from '../components/SalesToClientSupplierTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS, TRANSLATIONS } from '../constants';

const SalesToClientSuppliersPage: React.FC = () => {
  const [sales, setSales] = useLocalStorage<SaleToClientSupplier[]>(LOCAL_STORAGE_KEYS.SALES_TO_CLIENT_SUPPLIERS, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<SaleToClientSupplier | null>(null);

  const handleAddSale = (saleData: Omit<SaleToClientSupplier, 'id'>) => {
    const newSale: SaleToClientSupplier = {
      ...saleData,
      id: Date.now().toString(),
    };
    setSales([...sales, newSale].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setIsModalOpen(false);
  };

  const handleEditSale = (saleData: Omit<SaleToClientSupplier, 'id'>) => {
    if (!editingSale) return;
    setSales(
      sales.map((s) =>
        s.id === editingSale.id ? { id: s.id, ...saleData } : s
      ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    );
    setEditingSale(null);
    setIsModalOpen(false);
  };

  const openEditModal = (sale: SaleToClientSupplier) => {
    setEditingSale(sale);
    setIsModalOpen(true);
  };
  
  const handleDeleteSale = (saleId: string) => {
    if (window.confirm(TRANSLATIONS.confirmDeleteSale)) {
        setSales(sales.filter(s => s.id !== saleId));
    }
  };

  const openAddModal = () => {
    setEditingSale(null);
    setIsModalOpen(true);
  };

  return (
    <div>
      <PageTitle title={TRANSLATIONS.salesToClientSuppliers}>
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors"
          aria-label={TRANSLATIONS.addNewSaleToClientSupplier}
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>{TRANSLATIONS.addNewSaleToClientSupplier}</span>
        </button>
      </PageTitle>

      <SalesToClientSupplierTable sales={sales} onEdit={openEditModal} onDelete={handleDeleteSale} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingSale(null);
        }}
        title={editingSale ? TRANSLATIONS.editSaleToClientSupplier : TRANSLATIONS.addNewSaleToClientSupplier}
      >
        <SalesToClientSupplierForm
          onSubmit={editingSale ? handleEditSale : handleAddSale}
          onClose={() => {
            setIsModalOpen(false);
            setEditingSale(null);
          }}
          initialData={editingSale}
        />
      </Modal>
    </div>
  );
};

export default SalesToClientSuppliersPage;

import React, { useState, useEffect } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { Employee, Expense, InventoryItem, Supplier, RetailSale, SocialMediaSale, SaleToClientSupplier, SaleToClientTrader, DashboardSummary, BaseSaleOrder } from '../types';
import DashboardCard from '../components/DashboardCard';
import PageTitle from '../components/PageTitle';
import UserIcon from '../components/icons/UserIcon';
import DollarSignIcon from '../components/icons/DollarSignIcon';
import ClipboardListIcon from '../components/icons/ClipboardListIcon';
import ArchiveBoxIcon from '../components/icons/ArchiveBoxIcon';
import BuildingStorefrontIcon from '../components/icons/BuildingStorefrontIcon';
import ShoppingCartIcon from '../components/icons/ShoppingCartIcon';
import GlobeAltIcon from '../components/icons/GlobeAltIcon';
import BuildingLibraryIcon from '../components/icons/BuildingLibraryIcon';
import BriefcaseIcon from '../components/icons/BriefcaseIcon';
import { LOCAL_STORAGE_KEYS, TRANSLATIONS } from '../constants';

const DashboardPage: React.FC = () => {
  const [employees] = useLocalStorage<Employee[]>(LOCAL_STORAGE_KEYS.EMPLOYEES, []);
  const [expenses] = useLocalStorage<Expense[]>(LOCAL_STORAGE_KEYS.EXPENSES, []);
  const [inventoryItems] = useLocalStorage<InventoryItem[]>(LOCAL_STORAGE_KEYS.INVENTORY_ITEMS, []);
  const [suppliers] = useLocalStorage<Supplier[]>(LOCAL_STORAGE_KEYS.SUPPLIERS, []); // These are OUR suppliers
  const [retailSales] = useLocalStorage<RetailSale[]>(LOCAL_STORAGE_KEYS.RETAIL_SALES, []);
  const [socialMediaSales] = useLocalStorage<SocialMediaSale[]>(LOCAL_STORAGE_KEYS.SOCIAL_MEDIA_SALES, []);
  const [salesToClientSuppliers] = useLocalStorage<SaleToClientSupplier[]>(LOCAL_STORAGE_KEYS.SALES_TO_CLIENT_SUPPLIERS, []);
  const [salesToClientTraders] = useLocalStorage<SaleToClientTrader[]>(LOCAL_STORAGE_KEYS.SALES_TO_CLIENT_TRADERS, []);
  
  const [summary, setSummary] = useState<DashboardSummary>({
    totalEmployees: 0,
    totalMonthlyPayroll: 0,
    totalExpensesThisMonth: 0,
    totalInventoryItems: 0,
    totalInventoryValue: 0,
    totalSuppliers: 0,
    totalRetailSalesRevenueThisMonth: 0,
    totalRetailSalesProfitThisMonth: 0,
    totalSocialMediaSalesRevenueThisMonth: 0,
    totalSocialMediaSalesProfitThisMonth: 0,
    totalSalesToClientSuppliersRevenueThisMonth: 0,
    totalSalesToClientSuppliersProfitThisMonth: 0,
    totalSalesToClientTradersRevenueThisMonth: 0,
    totalSalesToClientTradersProfitThisMonth: 0,
  });

  useEffect(() => {
    const totalEmployees = employees.length;
    const totalMonthlyPayroll = employees.reduce((sum, emp) => sum + emp.monthlySalary, 0);

    const currentDate = new Date();
    const currentMonth = currentDate.getMonth();
    const currentYear = currentDate.getFullYear();

    const filterByCurrentMonth = (itemDateStr: string) => {
      const itemDate = new Date(itemDateStr + 'T00:00:00'); // Ensure correct date parsing
      return itemDate.getMonth() === currentMonth && itemDate.getFullYear() === currentYear;
    };
    
    const aggregateSalesData = (sales: BaseSaleOrder[]) => {
        return sales.filter(s => filterByCurrentMonth(s.date)).reduce(
            (acc, sale) => {
                acc.revenue += sale.totalRevenue;
                acc.profit += sale.totalProfit;
                return acc;
            }, { revenue: 0, profit: 0}
        );
    };

    const totalExpensesThisMonth = expenses
      .filter(exp => filterByCurrentMonth(exp.date))
      .reduce((sum, exp) => sum + exp.amount, 0);

    const totalInventoryItems = inventoryItems.length;
    const totalInventoryValue = inventoryItems.reduce((sum, item) => sum + (item.quantity * item.unitCost), 0);
    const totalSuppliers = suppliers.length; // Our suppliers

    const retailSalesSummary = aggregateSalesData(retailSales);
    const socialMediaSalesSummary = aggregateSalesData(socialMediaSales);
    const clientSupplierSalesSummary = aggregateSalesData(salesToClientSuppliers);
    const clientTraderSalesSummary = aggregateSalesData(salesToClientTraders);

    setSummary({
      totalEmployees,
      totalMonthlyPayroll,
      totalExpensesThisMonth,
      totalInventoryItems,
      totalInventoryValue,
      totalSuppliers,
      totalRetailSalesRevenueThisMonth: retailSalesSummary.revenue,
      totalRetailSalesProfitThisMonth: retailSalesSummary.profit,
      totalSocialMediaSalesRevenueThisMonth: socialMediaSalesSummary.revenue,
      totalSocialMediaSalesProfitThisMonth: socialMediaSalesSummary.profit,
      totalSalesToClientSuppliersRevenueThisMonth: clientSupplierSalesSummary.revenue,
      totalSalesToClientSuppliersProfitThisMonth: clientSupplierSalesSummary.profit,
      totalSalesToClientTradersRevenueThisMonth: clientTraderSalesSummary.revenue,
      totalSalesToClientTradersProfitThisMonth: clientTraderSalesSummary.profit,
    });
  }, [employees, expenses, inventoryItems, suppliers, retailSales, socialMediaSales, salesToClientSuppliers, salesToClientTraders]);

  const formatCurrency = (amount: number) => `$${amount.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;

  return (
    <div>
      <PageTitle title="نظرة عامة على لوحة التحكم" />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        <DashboardCard title="إجمالي الموظفين" value={summary.totalEmployees.toLocaleString('ar-EG')} icon={<UserIcon className="w-8 h-8" />} color="bg-blue-500" />
        <DashboardCard title="إجمالي كشوف المرتبات الشهرية" value={formatCurrency(summary.totalMonthlyPayroll)} icon={<DollarSignIcon className="w-8 h-8" />} color="bg-green-500" />
        <DashboardCard title="مصروفات هذا الشهر" value={formatCurrency(summary.totalExpensesThisMonth)} icon={<ClipboardListIcon className="w-8 h-8" />} color="bg-yellow-500" />
        <DashboardCard title="أصناف المخزون" value={summary.totalInventoryItems.toLocaleString('ar-EG')} icon={<ArchiveBoxIcon className="w-8 h-8" />} color="bg-indigo-500" />
        <DashboardCard title="قيمة المخزون (التكلفة)" value={formatCurrency(summary.totalInventoryValue)} icon={<ArchiveBoxIcon className="w-8 h-8" />} color="bg-purple-500" />
        <DashboardCard title="إجمالي الموردين (لنا)" value={summary.totalSuppliers.toLocaleString('ar-EG')} icon={<BuildingStorefrontIcon className="w-8 h-8" />} color="bg-pink-500" />
        
        {/* Retail Sales */}
        <DashboardCard title="إيرادات التجزئة (الشهر)" value={formatCurrency(summary.totalRetailSalesRevenueThisMonth)} icon={<ShoppingCartIcon className="w-8 h-8" />} color="bg-teal-500" />
        <DashboardCard title="أرباح التجزئة (الشهر)" value={formatCurrency(summary.totalRetailSalesProfitThisMonth)} icon={<DollarSignIcon className="w-8 h-8" />} color="bg-teal-600" />

        {/* Social Media Sales */}
        <DashboardCard title="إيرادات السوشيال (الشهر)" value={formatCurrency(summary.totalSocialMediaSalesRevenueThisMonth)} icon={<GlobeAltIcon className="w-8 h-8" />} color="bg-cyan-500" />
        <DashboardCard title="أرباح السوشيال (الشهر)" value={formatCurrency(summary.totalSocialMediaSalesProfitThisMonth)} icon={<DollarSignIcon className="w-8 h-8" />} color="bg-cyan-600" />

        {/* Sales to Client Suppliers */}
        <DashboardCard title={`إيرادات ${TRANSLATIONS.salesToClientSuppliers} (الشهر)`} value={formatCurrency(summary.totalSalesToClientSuppliersRevenueThisMonth)} icon={<BuildingLibraryIcon className="w-8 h-8" />} color="bg-orange-500" />
        <DashboardCard title={`أرباح ${TRANSLATIONS.salesToClientSuppliers} (الشهر)`} value={formatCurrency(summary.totalSalesToClientSuppliersProfitThisMonth)} icon={<DollarSignIcon className="w-8 h-8" />} color="bg-orange-600" />
        
        {/* Sales to Client Traders */}
        <DashboardCard title={`إيرادات ${TRANSLATIONS.salesToClientTraders} (الشهر)`} value={formatCurrency(summary.totalSalesToClientTradersRevenueThisMonth)} icon={<BriefcaseIcon className="w-8 h-8" />} color="bg-lime-500" />
        <DashboardCard title={`أرباح ${TRANSLATIONS.salesToClientTraders} (الشهر)`} value={formatCurrency(summary.totalSalesToClientTradersProfitThisMonth)} icon={<DollarSignIcon className="w-8 h-8" />} color="bg-lime-600" />

      </div>
      <div className="mt-12 bg-white p-6 rounded-lg shadow-lg">
        <h3 className="text-xl font-semibold text-neutral-dark mb-4">مرحباً بك في نظام المصنع المحاسبي الذكي</h3>
        <p className="text-neutral-DEFAULT mb-2">
          استخدم القائمة الجانبية لإدارة الموظفين، المصروفات، المخزون، الموردين (الذين نشتري منهم)، وتسجيل المبيعات المختلفة مع تتبع أرباحها.
        </p>
        <p className="text-neutral-DEFAULT">
          يمكنك أيضاً إنشاء تقارير مالية مدعومة بالذكاء الاصطناعي لتحليل أداء مصنعك بشكل دقيق.
        </p>
      </div>
    </div>
  );
};

export default DashboardPage;

import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { RetailSale } from '../types';
import RetailSaleForm from '../components/RetailSaleForm';
import RetailSalesTable from '../components/RetailSalesTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS, TRANSLATIONS } from '../constants';

const RetailSalesPage: React.FC = () => {
  const [retailSales, setRetailSales] = useLocalStorage<RetailSale[]>(LOCAL_STORAGE_KEYS.RETAIL_SALES, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<RetailSale | null>(null);

  const handleAddSale = (saleData: Omit<RetailSale, 'id'>) => {
    const newSale: RetailSale = {
      ...saleData,
      id: Date.now().toString(),
    };
    setRetailSales([...retailSales, newSale].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setIsModalOpen(false);
  };

  const handleEditSale = (saleData: Omit<RetailSale, 'id'>) => {
    if (!editingSale) return;
    setRetailSales(
      retailSales.map((s) =>
        s.id === editingSale.id ? { id: s.id, ...saleData } : s // Ensure id is preserved
      ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    );
    setEditingSale(null);
    setIsModalOpen(false);
  };

  const openEditModal = (sale: RetailSale) => {
    setEditingSale(sale);
    setIsModalOpen(true);
  };
  
  const handleDeleteSale = (saleId: string) => {
    if (window.confirm(TRANSLATIONS.confirmDeleteSale)) {
        setRetailSales(retailSales.filter(s => s.id !== saleId));
    }
  };

  const openAddModal = () => {
    setEditingSale(null);
    setIsModalOpen(true);
  };

  return (
    <div>
      <PageTitle title="إدارة مبيعات التجزئة (القطاعي)">
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-dark focus:ring-opacity-50"
          aria-label="تسجيل عملية بيع جديدة"
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>تسجيل بيع جديد</span>
        </button>
      </PageTitle>

      <RetailSalesTable sales={retailSales} onEdit={openEditModal} onDelete={handleDeleteSale} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingSale(null);
        }}
        title={editingSale ? 'تعديل بيانات عملية البيع' : 'تسجيل عملية بيع جديدة'}
      >
        <RetailSaleForm
          onSubmit={editingSale ? handleEditSale : handleAddSale}
          onClose={() => {
            setIsModalOpen(false);
            setEditingSale(null);
          }}
          initialData={editingSale}
        />
      </Modal>
    </div>
  );
};

export default RetailSalesPage;

import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { Supplier } from '../types';
import SupplierForm from '../components/SupplierForm';
import SupplierTable from '../components/SupplierTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS } from '../constants';

const SuppliersPage: React.FC = () => {
  const [suppliers, setSuppliers] = useLocalStorage<Supplier[]>(LOCAL_STORAGE_KEYS.SUPPLIERS, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  const handleAddSupplier = (supplierData: Omit<Supplier, 'id'>) => {
    const newSupplier: Supplier = {
      ...supplierData,
      id: Date.now().toString(),
    };
    setSuppliers([...suppliers, newSupplier].sort((a,b) => a.name.localeCompare(b.name)));
    setIsModalOpen(false);
  };

  const handleEditSupplier = (supplierData: Omit<Supplier, 'id'>) => {
    if (!editingSupplier) return;
    setSuppliers(
      suppliers.map((sup) =>
        sup.id === editingSupplier.id ? { ...sup, ...supplierData } : sup
      ).sort((a,b) => a.name.localeCompare(b.name))
    );
    setEditingSupplier(null);
    setIsModalOpen(false);
  };

  const openEditModal = (supplier: Supplier) => {
    setEditingSupplier(supplier);
    setIsModalOpen(true);
  };
  
  const handleDeleteSupplier = (supplierId: string) => {
    if (window.confirm('هل أنت متأكد أنك تريد حذف هذا المورد؟')) {
        setSuppliers(suppliers.filter(sup => sup.id !== supplierId));
    }
  };

  const openAddModal = () => {
    setEditingSupplier(null);
    setIsModalOpen(true);
  };

  return (
    <div>
      <PageTitle title="إدارة التجار والموردين">
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-dark focus:ring-opacity-50"
          aria-label="إضافة مورد جديد"
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>إضافة مورد/تاجر</span>
        </button>
      </PageTitle>

      <SupplierTable suppliers={suppliers} onEdit={openEditModal} onDelete={handleDeleteSupplier} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingSupplier(null);
        }}
        title={editingSupplier ? 'تعديل بيانات المورد' : 'إضافة مورد جديد'}
      >
        <SupplierForm
          onSubmit={editingSupplier ? handleEditSupplier : handleAddSupplier}
          onClose={() => {
            setIsModalOpen(false);
            setEditingSupplier(null);
          }}
          initialData={editingSupplier}
        />
      </Modal>
    </div>
  );
};

export default SuppliersPage;

import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { InventoryItem } from '../types';
import InventoryItemForm from '../components/InventoryItemForm';
import InventoryTable from '../components/InventoryTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS } from '../constants';

const InventoryPage: React.FC = () => {
  const [inventoryItems, setInventoryItems] = useLocalStorage<InventoryItem[]>(LOCAL_STORAGE_KEYS.INVENTORY_ITEMS, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InventoryItem | null>(null);

  const handleAddItem = (itemData: Omit<InventoryItem, 'id'>) => {
    const newItem: InventoryItem = {
      ...itemData,
      id: Date.now().toString(),
    };
    setInventoryItems([...inventoryItems, newItem].sort((a,b) => a.name.localeCompare(b.name)));
    setIsModalOpen(false);
  };

  const handleEditItem = (itemData: Omit<InventoryItem, 'id'>) => {
    if (!editingItem) return;
    setInventoryItems(
      inventoryItems.map((item) =>
        item.id === editingItem.id ? { ...item, ...itemData } : item
      ).sort((a,b) => a.name.localeCompare(b.name))
    );
    setEditingItem(null);
    setIsModalOpen(false);
  };

  const openEditModal = (item: InventoryItem) => {
    setEditingItem(item);
    setIsModalOpen(true);
  };
  
  const handleDeleteItem = (itemId: string) => {
    if (window.confirm('هل أنت متأكد أنك تريد حذف هذا الصنف من المخزون؟')) {
        setInventoryItems(inventoryItems.filter(item => item.id !== itemId));
    }
  };

  const openAddModal = () => {
    setEditingItem(null);
    setIsModalOpen(true);
  };

  return (
    <div>
      <PageTitle title="إدارة المخزون وأصناف البضاعة">
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-dark focus:ring-opacity-50"
          aria-label="إضافة صنف جديد"
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>إضافة صنف جديد</span>
        </button>
      </PageTitle>

      <InventoryTable items={inventoryItems} onEdit={openEditModal} onDelete={handleDeleteItem} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingItem(null);
        }}
        title={editingItem ? 'تعديل بيانات الصنف' : 'إضافة صنف جديد للمخزون'}
      >
        <InventoryItemForm
          onSubmit={editingItem ? handleEditItem : handleAddItem}
          onClose={() => {
            setIsModalOpen(false);
            setEditingItem(null);
          }}
          initialData={editingItem}
        />
      </Modal>
    </div>
  );
};

export default InventoryPage;

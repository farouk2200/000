import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { SocialMediaSale } from '../types';
import SocialMediaSaleForm from '../components/SocialMediaSaleForm';
import SocialMediaSalesTable from '../components/SocialMediaSalesTable';
import Modal from '../components/Modal';
import PageTitle from '../components/PageTitle';
import PlusCircleIcon from '../components/icons/PlusCircleIcon';
import { LOCAL_STORAGE_KEYS, TRANSLATIONS } from '../constants';

const SocialMediaSalesPage: React.FC = () => {
  const [socialMediaSales, setSocialMediaSales] = useLocalStorage<SocialMediaSale[]>(LOCAL_STORAGE_KEYS.SOCIAL_MEDIA_SALES, []);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSale, setEditingSale] = useState<SocialMediaSale | null>(null);

  const handleAddSale = (saleData: Omit<SocialMediaSale, 'id'>) => {
    const newSale: SocialMediaSale = {
      ...saleData,
      id: Date.now().toString(),
    };
    setSocialMediaSales([...socialMediaSales, newSale].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
    setIsModalOpen(false);
  };

  const handleEditSale = (saleData: Omit<SocialMediaSale, 'id'>) => {
    if (!editingSale) return;
    setSocialMediaSales(
      socialMediaSales.map((s) =>
        s.id === editingSale.id ? { id: s.id, ...saleData } : s // Ensure id is preserved
      ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    );
    setEditingSale(null);
    setIsModalOpen(false);
  };

  const openEditModal = (sale: SocialMediaSale) => {
    setEditingSale(sale);
    setIsModalOpen(true);
  };
  
  const handleDeleteSale = (saleId: string) => {
    if (window.confirm(TRANSLATIONS.confirmDeleteSale)) {
        setSocialMediaSales(socialMediaSales.filter(s => s.id !== saleId));
    }
  };

  const openAddModal = () => {
    setEditingSale(null);
    setIsModalOpen(true);
  };

  return (
    <div>
      <PageTitle title="إدارة مبيعات السوشيال ميديا">
        <button
          onClick={openAddModal}
          className="flex items-center space-x-2 px-4 py-2 bg-primary hover:bg-primary-dark text-white rounded-lg shadow-md transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-primary-dark focus:ring-opacity-50"
          aria-label="تسجيل عملية بيع جديدة عبر السوشيال ميديا"
        >
          <PlusCircleIcon className="w-5 h-5" />
          <span>تسجيل بيع جديد</span>
        </button>
      </PageTitle>

      <SocialMediaSalesTable sales={socialMediaSales} onEdit={openEditModal} onDelete={handleDeleteSale} />

      <Modal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingSale(null);
        }}
        title={editingSale ? 'تعديل بيانات عملية البيع' : 'تسجيل عملية بيع جديدة عبر السوشيال ميديا'}
      >
        <SocialMediaSaleForm
          onSubmit={editingSale ? handleEditSale : handleAddSale}
          onClose={() => {
            setIsModalOpen(false);
            setEditingSale(null);
          }}
          initialData={editingSale}
        />
      </Modal>
    </div>
  );
};

export default SocialMediaSalesPage;

import React, { useState } from 'react';
import useLocalStorage from '../hooks/useLocalStorage';
import { Employee, Expense, InventoryItem, Supplier, RetailSale, SocialMediaSale, SaleToClientSupplier, SaleToClientTrader } from '../types';
import PageTitle from '../components/PageTitle';
import { getFinancialInsights, isGeminiAvailable } from '../services/geminiService';
import LoadingSpinner from '../components/LoadingSpinner';
import CogIcon from '../components/icons/CogIcon';
import { LOCAL_STORAGE_KEYS, API_KEY_MESSAGE, TRANSLATIONS } from '../constants';

const ReportsPage: React.FC = () => {
  const [employees] = useLocalStorage<Employee[]>(LOCAL_STORAGE_KEYS.EMPLOYEES, []);
  const [expenses] = useLocalStorage<Expense[]>(LOCAL_STORAGE_KEYS.EXPENSES, []);
  const [inventoryItems] = useLocalStorage<InventoryItem[]>(LOCAL_STORAGE_KEYS.INVENTORY_ITEMS, []);
  const [suppliers] = useLocalStorage<Supplier[]>(LOCAL_STORAGE_KEYS.SUPPLIERS, []);
  const [retailSales] = useLocalStorage<RetailSale[]>(LOCAL_STORAGE_KEYS.RETAIL_SALES, []);
  const [socialMediaSales] = useLocalStorage<SocialMediaSale[]>(LOCAL_STORAGE_KEYS.SOCIAL_MEDIA_SALES, []);
  const [salesToClientSuppliers] = useLocalStorage<SaleToClientSupplier[]>(LOCAL_STORAGE_KEYS.SALES_TO_CLIENT_SUPPLIERS, []);
  const [salesToClientTraders] = useLocalStorage<SaleToClientTrader[]>(LOCAL_STORAGE_KEYS.SALES_TO_CLIENT_TRADERS, []);
  
  const [question, setQuestion] = useState<string>('');
  const [report, setReport] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const geminiAvailable = isGeminiAvailable();

  const handleGenerateReport = async () => {
    if (!question.trim() || !geminiAvailable) {
      if (!geminiAvailable) {
        setReport(API_KEY_MESSAGE);
      } else {
        setReport("الرجاء إدخال سؤال لإنشاء التقرير.");
      }
      return;
    }
    setIsLoading(true);
    setReport(null);
    const result = await getFinancialInsights(
        question, 
        employees, 
        expenses, 
        inventoryItems, 
        suppliers, 
        retailSales, 
        socialMediaSales,
        salesToClientSuppliers,
        salesToClientTraders
    );
    setReport(result);
    setIsLoading(false);
  };

  const quickQuestions = [
    "ما هو إجمالي المصروفات الشهر الماضي؟",
    "أي فئة مصروفات كانت الأعلى إنفاقًا؟",
    "ما هي قيمة المخزون الحالية بناءً على تكلفتنا للوحدة؟",
    "ما هي أكثر 5 أصناف ربحية في مبيعات التجزئة هذا الشهر؟",
    "كم إجمالي الربح من مبيعات السوشيال ميديا الأسبوع الماضي؟",
    `ما هو متوسط الربح لكل عملية بيع للعملاء الموردين؟`,
    `ما هو إجمالي إيرادات مبيعات العملاء التجار هذا الشهر؟ وما هو إجمالي ربحهم؟`,
    "لخص الوضع المالي الحالي مع التركيز على الربحية.",
    "كم عدد الموظفين الذين تم تعيينهم هذا العام؟",
    "ما هو متوسط راتب الموظف؟",
    "ما هي المنتجات الأكثر مبيعًا عبر جميع القنوات هذا الشهر؟",
    "قارن بين ربحية مبيعات التجزئة ومبيعات السوشيال ميديا.",
  ];

  return (
    <div>
      <PageTitle title="تقارير مالية بالذكاء الاصطناعي" />

      {!geminiAvailable && (
        <div className="mb-6 p-4 bg-red-100 ltr:border-l-4 rtl:border-r-4 border-red-500 text-red-700 rounded-md">
            <p className="font-semibold">Gemini API غير متاح</p>
            <p>{API_KEY_MESSAGE} تتطلب هذه الميزة مفتاح API صالحًا.</p>
        </div>
      )}

      <div className="bg-white p-6 rounded-lg shadow-lg">
        <div className="mb-6">
          <label htmlFor="reportQuestion" className="block text-sm font-medium text-neutral-DEFAULT mb-1">
            اطرح سؤالاً حول ماليات مصنعك، موظفيك، مخزونك، أو مبيعاتك وربحيتها:
          </label>
          <textarea
            id="reportQuestion"
            rows={3}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="مثال: ما هي أعلى 3 أصناف ربحية هذا الشهر؟ ما هو الصنف الأقل كمية في المخزون؟"
            className="w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-primary focus:border-primary disabled:bg-gray-100"
            disabled={!geminiAvailable || isLoading}
          />
        </div>

        <div className="mb-6">
            <p className="text-sm font-medium text-neutral-DEFAULT mb-2">أو جرب سؤالاً سريعًا:</p>
            <div className="flex flex-wrap gap-2">
                {quickQuestions.map(q => (
                    <button 
                        key={q}
                        onClick={() => setQuestion(q)}
                        className="px-3 py-1.5 text-xs bg-primary-light/20 text-primary-dark hover:bg-primary-light/40 rounded-full transition-colors disabled:opacity-50"
                        disabled={!geminiAvailable || isLoading}
                    >
                        {q}
                    </button>
                ))}
            </div>
        </div>

        <button
          onClick={handleGenerateReport}
          disabled={isLoading || !geminiAvailable || !question.trim()}
          className="w-full flex items-center justify-center space-x-2 px-6 py-3 bg-secondary hover:bg-emerald-600 text-white rounded-lg shadow-md transition-colors duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-secondary focus:ring-opacity-50 disabled:bg-gray-300 disabled:cursor-not-allowed"
        >
          {isLoading ? <LoadingSpinner size="sm" /> : <CogIcon className="w-5 h-5" />}
          <span>{isLoading ? 'جاري إنشاء التقرير...' : 'اسأل المساعد الذكي'}</span>
        </button>

        {report && (
          <div className="mt-8 p-6 bg-neutral-light rounded-lg border border-gray-200">
            <h4 className="text-lg font-semibold text-neutral-dark mb-3">التقرير المُنشأ بواسطة الذكاء الاصطناعي:</h4>
            <pre className="whitespace-pre-wrap text-sm text-neutral-DEFAULT bg-white p-4 rounded shadow-inner font-sans text-start">{report}</pre>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportsPage;

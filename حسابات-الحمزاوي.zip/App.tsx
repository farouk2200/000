import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import DashboardPage from './pages/DashboardPage';
import EmployeesPage from './pages/EmployeesPage';
import ExpensesPage from './pages/ExpensesPage';
import InventoryPage from './pages/InventoryPage';
import SuppliersPage from './pages/SuppliersPage';
import RetailSalesPage from './pages/RetailSalesPage';
import SocialMediaSalesPage from './pages/SocialMediaSalesPage';
import SalesToClientSuppliersPage from './pages/SalesToClientSuppliersPage';
import SalesToClientTradersPage from './pages/SalesToClientTradersPage';
import ReportsPage from './pages/ReportsPage';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/employees" element={<EmployeesPage />} />
          <Route path="/expenses" element={<ExpensesPage />} />
          <Route path="/inventory" element={<InventoryPage />} />
          <Route path="/suppliers" element={<SuppliersPage />} />
          <Route path="/sales-to-client-suppliers" element={<SalesToClientSuppliersPage />} />
          <Route path="/sales-to-client-traders" element={<SalesToClientTradersPage />} />
          <Route path="/retailsales" element={<RetailSalesPage />} />
          <Route path="/socialmediasales" element={<SocialMediaSalesPage />} />
          <Route path="/reports" element={<ReportsPage />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;

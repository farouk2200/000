import { EXPENSE_CATEGORIES, SOCIAL_MEDIA_PLATFORMS as APP_SOCIAL_MEDIA_PLATFORMS } from './constants';

export interface Employee {
  id: string;
  name: string;
  role: string;
  monthlySalary: number;
  hireDate: string; // ISO date string YYYY-MM-DD
}

export type ExpenseCategoryKey = typeof EXPENSE_CATEGORIES[number];

export interface Expense {
  id: string;
  description: string;
  amount: number;
  date: string; // ISO date string YYYY-MM-DD
  category: ExpenseCategoryKey;
}

export interface NavItemType {
  path: string;
  name: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
}

export interface InventoryItem {
  id: string;
  name: string;
  sku: string; // Stock Keeping Unit
  quantity: number;
  unitCost: number; // Cost per unit (our cost)
  unitPrice: number; // General selling price per unit
}

export interface Supplier { // This is OUR supplier (we buy from them)
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  address: string;
}

// Enhanced SaleItem to track profit
export interface SaleItem {
  productId?: string; // Optional: Link to InventoryItem.id for better cost fetching in future
  productName: string;
  quantity: number;
  unitCostAtSale: number; // Our cost for this item at the time of this specific sale
  sellingPrice: number; // Actual selling price for this item in this sale
  profit: number; // Calculated: (sellingPrice - unitCostAtSale) * quantity
}

// Base interface for all sales orders/invoices
export interface BaseSaleOrder {
  id: string;
  date: string; // ISO date string YYYY-MM-DD
  items: SaleItem[];
  totalCostOfGoods: number; // Sum of (item.unitCostAtSale * item.quantity)
  totalRevenue: number;     // Sum of (item.sellingPrice * item.quantity)
  totalProfit: number;      // totalRevenue - totalCostOfGoods
  notes?: string;
}

export interface RetailSale extends BaseSaleOrder {
  // RetailSale might have specific fields in the future, but for now, it's a BaseSaleOrder
}

export const SOCIAL_MEDIA_PLATFORMS = APP_SOCIAL_MEDIA_PLATFORMS; // Re-exporting for clarity
export type SocialMediaPlatformType = typeof SOCIAL_MEDIA_PLATFORMS[number];

export interface SocialMediaSale extends BaseSaleOrder {
  platform: SocialMediaPlatformType;
  customerIdentifier: string; // e.g., username, phone number
  shippingAddress?: string;
}

// For sales to clients who are suppliers (e.g. distributors)
export interface SaleToClientSupplier extends BaseSaleOrder {
  clientSupplierName: string; // Name of the supplier client we are selling to
}

// For sales to clients who are traders
export interface SaleToClientTrader extends BaseSaleOrder {
  clientTraderName: string; // Name of the trader client we are selling to
}

export interface DashboardSummary {
  totalEmployees: number;
  totalMonthlyPayroll: number;
  totalExpensesThisMonth: number;
  totalInventoryItems: number;
  totalInventoryValue: number; // Based on InventoryItem.unitCost
  totalSuppliers: number; // Our suppliers

  totalRetailSalesRevenueThisMonth: number;
  totalRetailSalesProfitThisMonth: number;

  totalSocialMediaSalesRevenueThisMonth: number;
  totalSocialMediaSalesProfitThisMonth: number;

  totalSalesToClientSuppliersRevenueThisMonth: number;
  totalSalesToClientSuppliersProfitThisMonth: number;

  totalSalesToClientTradersRevenueThisMonth: number;
  totalSalesToClientTradersProfitThisMonth: number;
}

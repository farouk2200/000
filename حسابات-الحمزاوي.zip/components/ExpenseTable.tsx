
import React from 'react';
import { Expense } from '../types';
import { EXPENSE_CATEGORY_TRANSLATIONS } from '../constants';

interface ExpenseTableProps {
  expenses: Expense[];
  onEdit?: (expense: Expense) => void;
  onDelete?: (expenseId: string) => void;
}

const ExpenseTable: React.FC<ExpenseTableProps> = ({ expenses, onEdit, onDelete }) => {
  if (expenses.length === 0) {
    return <p className="text-neutral-DEFAULT text-center py-8">لم يتم العثور على مصروفات. سجل البعض للبدء!</p>;
  }

  return (
    <div className="overflow-x-auto bg-white shadow-md rounded-lg">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الوصف</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">المبلغ</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الفئة</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">التاريخ</th>
            {(onEdit || onDelete) && <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الإجراءات</th>}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {expenses.map((expense) => (
            <tr key={expense.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="text-sm text-neutral-dark">{expense.description}</div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">${expense.amount.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td className="px-6 py-4 whitespace-nowrap">
                <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                  {EXPENSE_CATEGORY_TRANSLATIONS[expense.category] || expense.category}
                </span>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{new Date(expense.date + 'T00:00:00').toLocaleDateString('ar-EG')}</td>
              {(onEdit || onDelete) && (
                 <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  {onEdit && (
                    <button onClick={() => onEdit(expense)} className="text-primary hover:text-primary-dark transition-colors">تعديل</button>
                  )}
                  {onDelete && (
                    <button onClick={() => onDelete(expense.id)} className="text-red-600 hover:text-red-800 transition-colors">حذف</button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ExpenseTable;
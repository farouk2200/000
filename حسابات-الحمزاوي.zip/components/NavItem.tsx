
import React from 'react';
import { NavLink } from 'react-router-dom';
import { NavItemType } from '../types';

interface NavItemProps {
  item: NavItemType;
}

const NavItem: React.FC<NavItemProps> = ({ item }) => {
  return (
    <NavLink
      to={item.path}
      className={({ isActive }) =>
        `flex items-center space-x-3 p-3 rounded-lg transition-colors duration-150 ease-in-out
        hover:bg-primary-dark/70 focus:outline-none focus:ring-2 focus:ring-primary-light
        ${isActive ? 'bg-primary-dark/80 shadow-inner' : 'hover:bg-primary-dark/60'}`
      }
    >
      <item.icon className="w-5 h-5" />
      <span>{item.name}</span>
    </NavLink>
  );
};

export default NavItem;

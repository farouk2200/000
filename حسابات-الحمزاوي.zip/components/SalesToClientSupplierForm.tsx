import React, { useState, useEffect } from 'react';
import { SaleToClientSupplier, SaleItem } from '../types';
import PlusCircleIcon from './icons/PlusCircleIcon';
import XCircleIcon from './icons/XCircleIcon';
import { TRANSLATIONS, LOCAL_STORAGE_KEYS as LS_KEYS } from '../constants';
import useLocalStorage from '../hooks/useLocalStorage';
import { InventoryItem } from '../types';

interface SalesToClientSupplierFormProps {
  onSubmit: (sale: Omit<SaleToClientSupplier, 'id'>) => void;
  onClose: () => void;
  initialData?: SaleToClientSupplier | null;
}

const SalesToClientSupplierForm: React.FC<SalesToClientSupplierFormProps> = ({ onSubmit, onClose, initialData }) => {
  const [date, setDate] = useState('');
  const [clientSupplierName, setClientSupplierName] = useState('');
  const [items, setItems] = useState<SaleItem[]>([]);
  const [notes, setNotes] = useState('');
  const [inventoryItems] = useLocalStorage<InventoryItem[]>(LS_KEYS.INVENTORY_ITEMS, []);

  const [currentProductName, setCurrentProductName] = useState('');
  const [currentQuantity, setCurrentQuantity] = useState<number | ''>('');
  const [currentUnitCostAtSale, setCurrentUnitCostAtSale] = useState<number | ''>('');
  const [currentSellingPrice, setCurrentSellingPrice] = useState<number | ''>('');
  const [selectedInventoryItemForCost, setSelectedInventoryItemForCost] = useState<string>('');

  useEffect(() => {
    if (initialData) {
      setDate(initialData.date);
      setClientSupplierName(initialData.clientSupplierName);
      setItems(initialData.items);
      setNotes(initialData.notes || '');
    } else {
      setDate(new Date().toISOString().split('T')[0]);
      setClientSupplierName('');
      setItems([]);
      setNotes('');
    }
  }, [initialData]);

  useEffect(() => {
    if (selectedInventoryItemForCost) {
        const foundItem = inventoryItems.find(invItem => invItem.id === selectedInventoryItemForCost);
        if (foundItem) {
            setCurrentProductName(foundItem.name);
            setCurrentUnitCostAtSale(foundItem.unitCost);
            setCurrentSellingPrice(foundItem.unitPrice);
        }
    }
  }, [selectedInventoryItemForCost, inventoryItems]);

  const handleAddItem = () => {
    if (!currentProductName.trim() || currentQuantity === '' || currentUnitCostAtSale === '' || currentSellingPrice === '' || 
        isNaN(Number(currentQuantity)) || isNaN(Number(currentUnitCostAtSale)) || isNaN(Number(currentSellingPrice))) {
      alert(TRANSLATIONS.completeItemDetailsCorrectly);
      return;
    }
    const quantity = Number(currentQuantity);
    const unitCost = Number(currentUnitCostAtSale);
    const sellingPrice = Number(currentSellingPrice);

    const newItem: SaleItem = {
      productName: currentProductName,
      quantity: quantity,
      unitCostAtSale: unitCost,
      sellingPrice: sellingPrice,
      profit: (sellingPrice - unitCost) * quantity,
      // productId: selectedInventoryItemForCost || undefined,
    };
    setItems([...items, newItem]);
    setCurrentProductName('');
    setCurrentQuantity('');
    setCurrentUnitCostAtSale('');
    setCurrentSellingPrice('');
    setSelectedInventoryItemForCost('');
  };

  const handleRemoveItem = (index: number) => {
    setItems(items.filter((_, i) => i !== index));
  };

  const calculateTotals = () => {
    const totalCostOfGoods = items.reduce((sum, item) => sum + (item.unitCostAtSale * item.quantity), 0);
    const totalRevenue = items.reduce((sum, item) => sum + (item.sellingPrice * item.quantity), 0);
    const totalProfit = totalRevenue - totalCostOfGoods;
    return { totalCostOfGoods, totalRevenue, totalProfit };
  };
  const { totalCostOfGoods, totalRevenue, totalProfit } = calculateTotals();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) {
      alert(TRANSLATIONS.addAtLeastOneItem);
      return;
    }
    if (!clientSupplierName.trim()) {
      alert(`الرجاء إدخال ${TRANSLATIONS.clientSupplierName}.`);
      return;
    }
    onSubmit({ 
      date, 
      clientSupplierName,
      items,
      totalCostOfGoods,
      totalRevenue,
      totalProfit,
      notes 
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="saleDateCS" className="block text-sm font-medium text-neutral-DEFAULT">تاريخ البيع</label>
          <input type="date" id="saleDateCS" value={date} onChange={(e) => setDate(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
        </div>
        <div>
          <label htmlFor="clientSupplierName" className="block text-sm font-medium text-neutral-DEFAULT">{TRANSLATIONS.clientSupplierName}</label>
          <input type="text" id="clientSupplierName" value={clientSupplierName} onChange={(e) => setClientSupplierName(e.target.value)} required className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
        </div>
      </div>
      
      <fieldset className="border border-gray-300 p-4 rounded-md">
        <legend className="text-sm font-medium text-neutral-DEFAULT px-1">الأصناف المباعة</legend>
        {items.length > 0 && (
          <ul className="space-y-2 mb-4 max-h-48 overflow-y-auto">
            {items.map((item, index) => (
              <li key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded-md text-xs">
                <div>
                  <p className="font-semibold">{item.productName}</p>
                  <p>الكمية: {item.quantity.toLocaleString('ar-EG')} ، تكلفتنا: ${item.unitCostAtSale.toLocaleString('ar-EG')} ، سعر البيع: ${item.sellingPrice.toLocaleString('ar-EG')}</p>
                  <p className="text-green-600">{TRANSLATIONS.profitForItem}: ${item.profit.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
                </div>
                <button type="button" onClick={() => handleRemoveItem(index)} className="text-red-500 hover:text-red-700">
                  <XCircleIcon className="w-5 h-5" />
                </button>
              </li>
            ))}
          </ul>
        )}
        <div className="space-y-3 border-t border-gray-200 pt-3">
           <p className="text-xs text-neutral-DEFAULT mb-1">إضافة صنف جديد لعملية البيع:</p>
            <div>
              <label htmlFor="inventoryItemLookupCS" className="block text-xs font-medium text-neutral-DEFAULT">اختيار من المخزون (لتعبئة التكلفة والاسم)</label>
              <select
                id="inventoryItemLookupCS"
                value={selectedInventoryItemForCost}
                onChange={(e) => setSelectedInventoryItemForCost(e.target.value)}
                className="mt-1 block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-xs"
              >
                <option value="">-- اختر صنفًا (اختياري) --</option>
                {inventoryItems.map(invItem => (
                  <option key={invItem.id} value={invItem.id}>{invItem.name} (المخزون: {invItem.quantity}, تكلفتنا: ${invItem.unitCost})</option>
                ))}
              </select>
            </div>
            <div>
                <label htmlFor="currentItemNameCS" className="block text-xs font-medium text-neutral-DEFAULT">اسم المنتج أو الصنف</label>
                <input type="text" id="currentItemNameCS" value={currentProductName} onChange={(e) => setCurrentProductName(e.target.value)} required className="mt-1 block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-xs" />
            </div>
            <div className="grid grid-cols-3 gap-3">
                <div>
                <label htmlFor="currentItemQuantityCS" className="block text-xs font-medium text-neutral-DEFAULT">{TRANSLATIONS.quantityOrdered}</label>
                <input type="number" id="currentItemQuantityCS" value={currentQuantity} min="1" onChange={(e) => setCurrentQuantity(e.target.value === '' ? '' : parseInt(e.target.value))} required className="mt-1 block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-xs" />
                </div>
                <div>
                <label htmlFor="currentUnitCostAtSaleCS" className="block text-xs font-medium text-neutral-DEFAULT">{TRANSLATIONS.ourUnitCost}</label>
                <input type="number" id="currentUnitCostAtSaleCS" value={currentUnitCostAtSale} min="0" step="0.01" onChange={(e) => setCurrentUnitCostAtSale(e.target.value === '' ? '' : parseFloat(e.target.value))} required className="mt-1 block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-xs" />
                </div>
                <div>
                <label htmlFor="currentSellingPriceCS" className="block text-xs font-medium text-neutral-DEFAULT">{TRANSLATIONS.sellingPriceToCustomer}</label>
                <input type="number" id="currentSellingPriceCS" value={currentSellingPrice} min="0" step="0.01" onChange={(e) => setCurrentSellingPrice(e.target.value === '' ? '' : parseFloat(e.target.value))} required className="mt-1 block w-full px-2 py-1 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-xs" />
                </div>
            </div>
            {currentQuantity !== '' && currentUnitCostAtSale !== '' && currentSellingPrice !== '' && !isNaN(Number(currentQuantity)) && !isNaN(Number(currentUnitCostAtSale)) && !isNaN(Number(currentSellingPrice)) && (
                 <p className="text-xs text-green-700">{TRANSLATIONS.profitForItem}: ${((Number(currentSellingPrice) - Number(currentUnitCostAtSale)) * Number(currentQuantity)).toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
            )}
          <button type="button" onClick={handleAddItem} className="w-full flex items-center justify-center space-x-2 px-3 py-1.5 text-xs font-medium text-white bg-green-600 hover:bg-green-700 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-green-500">
            <PlusCircleIcon className="w-4 h-4" />
            <span>{TRANSLATIONS.addItemToInvoice}</span>
          </button>
        </div>
      </fieldset>
      
      <div className="space-y-1 text-sm border-t pt-4">
        <p><span className="font-medium">{TRANSLATIONS.totalCostOfGoods}:</span> ${totalCostOfGoods.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
        <p><span className="font-medium">{TRANSLATIONS.totalRevenue}:</span> ${totalRevenue.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
        <p className="font-semibold text-green-600"><span className="font-medium">{TRANSLATIONS.totalProfit}:</span> ${totalProfit.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</p>
      </div>

      <div>
        <label htmlFor="saleNotesCS" className="block text-sm font-medium text-neutral-DEFAULT">ملاحظات (اختياري)</label>
        <textarea id="saleNotesCS" rows={2} value={notes} onChange={(e) => setNotes(e.target.value)} className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm" />
      </div>

      <div className="flex justify-end space-x-3 pt-2">
        <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-neutral-DEFAULT bg-neutral-light hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400">إلغاء</button>
        <button type="submit" disabled={items.length === 0 || !clientSupplierName.trim()} className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark disabled:opacity-50">
          {initialData ? TRANSLATIONS.editSaleToClientSupplier : TRANSLATIONS.addNewSaleToClientSupplier}
        </button>
      </div>
    </form>
  );
};

export default SalesToClientSupplierForm;
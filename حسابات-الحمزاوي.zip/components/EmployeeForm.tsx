
import React, { useState, useEffect } from 'react';
import { Employee } from '../types';

interface EmployeeFormProps {
  onSubmit: (employee: Omit<Employee, 'id'>) => void;
  onClose: () => void;
  initialData?: Employee | null;
}

const EmployeeForm: React.FC<EmployeeFormProps> = ({ onSubmit, onClose, initialData }) => {
  const [name, setName] = useState('');
  const [role, setRole] = useState('');
  const [monthlySalary, setMonthlySalary] = useState<number | ''>('');
  const [hireDate, setHireDate] = useState('');

  useEffect(() => {
    if (initialData) {
      setName(initialData.name);
      setRole(initialData.role);
      setMonthlySalary(initialData.monthlySalary);
      setHireDate(initialData.hireDate);
    } else {
      // Set default hire date to today for new employees
      setHireDate(new Date().toISOString().split('T')[0]);
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (monthlySalary === '' || isNaN(Number(monthlySalary))) {
        alert("الرجاء إدخال راتب صحيح.");
        return;
    }
    onSubmit({ name, role, monthlySalary: Number(monthlySalary), hireDate });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="employeeName" className="block text-sm font-medium text-neutral-DEFAULT">
          الاسم الكامل
        </label>
        <input
          type="text"
          id="employeeName"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          autoFocus
        />
      </div>
      <div>
        <label htmlFor="employeeRole" className="block text-sm font-medium text-neutral-DEFAULT">
          المنصب / الدور الوظيفي
        </label>
        <input
          type="text"
          id="employeeRole"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
        />
      </div>
      <div>
        <label htmlFor="monthlySalary" className="block text-sm font-medium text-neutral-DEFAULT">
          الراتب الشهري ($)
        </label>
        <input
          type="number"
          id="monthlySalary"
          value={monthlySalary}
          onChange={(e) => setMonthlySalary(e.target.value === '' ? '' : parseFloat(e.target.value))}
          required
          min="0"
          step="0.01"
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
        />
      </div>
      <div>
        <label htmlFor="hireDate" className="block text-sm font-medium text-neutral-DEFAULT">
          تاريخ التعيين
        </label>
        <input
          type="date"
          id="hireDate"
          value={hireDate}
          onChange={(e) => setHireDate(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
        />
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-neutral-DEFAULT bg-neutral-light hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
        >
          إلغاء
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark"
        >
          {initialData ? 'تحديث بيانات الموظف' : 'إضافة موظف'}
        </button>
      </div>
    </form>
  );
};

export default EmployeeForm;
import React from 'react';
import ReactDOM from 'react-dom/client';
import { RetailSale } from '../types';
import { TRANSLATIONS } from '../constants';
import PrinterIcon from './icons/PrinterIcon';
import InvoiceTemplate from './InvoiceTemplate';

interface RetailSalesTableProps {
  sales: RetailSale[];
  onEdit?: (sale: RetailSale) => void;
  onDelete?: (saleId: string) => void;
}

const RetailSalesTable: React.FC<RetailSalesTableProps> = ({ sales, onEdit, onDelete }) => {
  if (sales.length === 0) {
    return <p className="text-neutral-DEFAULT text-center py-8">لا توجد مبيعات تجزئة مسجلة. سجل البعض للبدء.</p>;
  }
  
  const handlePrintInvoice = (sale: RetailSale) => {
    const printWindow = window.open('', '_blank', 'height=800,width=800');
    if (printWindow) {
      printWindow.document.write(`
        <html>
          <head>
            <title>${TRANSLATIONS.invoiceTitleRetail}</title>
            <meta charset="UTF-8">
            <link rel="preconnect" href="https://fonts.googleapis.com">
            <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
            <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;500;600;700&display=swap" rel="stylesheet">
            <style> body { direction: rtl; font-family: 'Cairo', sans-serif; } </style>
          </head>
          <body>
            <div id="invoice-root"></div>
          </body>
        </html>
      `);
      printWindow.document.close();

      const invoiceRoot = printWindow.document.getElementById('invoice-root');
      if (invoiceRoot) {
        const root = ReactDOM.createRoot(invoiceRoot);
        root.render(
          <React.StrictMode>
            <InvoiceTemplate 
              saleData={sale} 
              invoiceTitle={TRANSLATIONS.invoiceTitleRetail} 
              onReady={() => {
                // Ensure content is rendered before printing
                setTimeout(() => {
                    printWindow.focus();
                    printWindow.print();
                    // printWindow.close(); // Optional: close after print dialog
                }, 250);
              }}
            />
          </React.StrictMode>
        );
      }
    } else {
      alert('الرجاء تعطيل مانع النوافذ المنبثقة لطباعة الفاتورة.');
    }
  };

  return (
    <div className="overflow-x-auto bg-white shadow-md rounded-lg">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">رقم الفاتورة (ID)</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">التاريخ</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">{TRANSLATIONS.totalItems}</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">{TRANSLATIONS.totalCostOfGoods}</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">{TRANSLATIONS.totalRevenue}</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">{TRANSLATIONS.totalProfit}</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">ملاحظات</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الإجراءات</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {sales.map((sale) => (
            <tr key={sale.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-dark">{sale.id.slice(-8)}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{new Date(sale.date + 'T00:00:00').toLocaleDateString('ar-EG')}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{sale.items.length.toLocaleString('ar-EG')}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">${sale.totalCostOfGoods.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">${sale.totalRevenue.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-green-600">${sale.totalProfit.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td className="px-6 py-4 whitespace-normal text-sm text-neutral-DEFAULT max-w-xs truncate" title={sale.notes}>{sale.notes || '-'}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-1 rtl:space-x-reverse">
                  <button 
                    onClick={() => handlePrintInvoice(sale)} 
                    className="text-blue-600 hover:text-blue-800 transition-colors p-1"
                    title={TRANSLATIONS.printInvoice}
                    aria-label={TRANSLATIONS.printInvoice}
                  >
                    <PrinterIcon className="w-5 h-5" />
                  </button>
                  {onEdit && (
                    <button onClick={() => onEdit(sale)} className="text-primary hover:text-primary-dark transition-colors p-1">تعديل</button>
                  )}
                  {onDelete && (
                    <button onClick={() => onDelete(sale.id)} className="text-red-600 hover:text-red-800 transition-colors p-1">حذف</button>
                  )}
                </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default RetailSalesTable;
import React from 'react';
import { InventoryItem } from '../types';

interface InventoryTableProps {
  items: InventoryItem[];
  onEdit?: (item: InventoryItem) => void;
  onDelete?: (itemId: string) => void;
}

const InventoryTable: React.FC<InventoryTableProps> = ({ items, onEdit, onDelete }) => {
  if (items.length === 0) {
    return <p className="text-neutral-DEFAULT text-center py-8">لا توجد أصناف في المخزون. أضف بعض الأصناف للبدء.</p>;
  }

  return (
    <div className="overflow-x-auto bg-white shadow-md rounded-lg">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">اسم الصنف</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">SKU</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الكمية</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">تكلفة الوحدة</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">سعر البيع</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">القيمة الإجمالية (التكلفة)</th>
            {(onEdit || onDelete) && <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الإجراءات</th>}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {items.map((item) => (
            <tr key={item.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-dark">{item.name}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{item.sku || 'N/A'}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{item.quantity.toLocaleString('ar-EG')}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">${item.unitCost.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">${item.unitPrice.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">${(item.quantity * item.unitCost).toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              {(onEdit || onDelete) && (
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  {onEdit && (
                    <button onClick={() => onEdit(item)} className="text-primary hover:text-primary-dark transition-colors">تعديل</button>
                  )}
                  {onDelete && (
                    <button onClick={() => onDelete(item.id)} className="text-red-600 hover:text-red-800 transition-colors">حذف</button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default InventoryTable;

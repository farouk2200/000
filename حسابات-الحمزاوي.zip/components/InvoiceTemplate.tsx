import React from 'react';
import { BaseSaleOrder, SaleItem, SaleToClientSupplier, SaleToClientTrader, SocialMediaSale } from '../types';
import { APP_NAME, TRANSLATIONS, SOCIAL_MEDIA_PLATFORM_TRANSLATIONS } from '../constants';

interface InvoiceTemplateProps {
  saleData: BaseSaleOrder;
  invoiceTitle: string;
  onReady?: () => void; // Callback for when component is mounted and ready for print
}

const InvoiceTemplate: React.FC<InvoiceTemplateProps> = ({ saleData, invoiceTitle, onReady }) => {
  
  React.useEffect(() => {
    if (onReady) {
      onReady();
    }
  }, [onReady]);

  const { id, date, items, totalCostOfGoods, totalRevenue, totalProfit, notes } = saleData;

  const clientSupplierSale = saleData as SaleToClientSupplier;
  const clientTraderSale = saleData as SaleToClientTrader;
  const socialMediaSale = saleData as SocialMediaSale;

  const formatCurrency = (amount: number) => {
    return amount.toLocaleString('ar-EG', { style: 'currency', currency: 'USD', minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };
  
  return (
    <div style={{ direction: 'rtl', fontFamily: "'Cairo', 'Inter', sans-serif", padding: '20px', color: '#333' }}>
      <style>
        {`
          @media print {
            body {
              -webkit-print-color-adjust: exact;
              print-color-adjust: exact;
              margin: 0;
              padding: 10mm;
              font-size: 10pt;
            }
            .no-print {
              display: none !important;
            }
            table {
              width: 100%;
              border-collapse: collapse;
            }
            th, td {
              border: 1px solid #ddd;
              padding: 6px;
              text-align: right;
            }
            th {
              background-color: #f2f2f2;
            }
            .header, .footer {
                width: 100%;
            }
            .header {
                text-align: center;
                margin-bottom: 20px;
                border-bottom: 2px solid #333;
                padding-bottom: 10px;
            }
            .totals-section {
                margin-top: 20px;
                padding-top: 10px;
                border-top: 1px solid #eee;
            }
             .totals-section p {
                margin: 3px 0;
            }
            .footer p {
                margin: 2px 0;
            }
          }
          /* Screen styles for preview */
          .invoice-container { max-width: 800px; margin: auto; background: white; border: 1px solid #ccc; }
          .invoice-container table { width: 100%; border-collapse: collapse; }
          .invoice-container th, .invoice-container td { border: 1px solid #ddd; padding: 8px; text-align: right; }
          .invoice-container th { background-color: #f2f2f2; }
          .invoice-container .header { text-align: center; margin-bottom: 20px; border-bottom: 2px solid #333; padding-bottom: 10px; }
          .invoice-container .totals-section { margin-top: 20px; padding-top: 10px; border-top: 1px solid #eee; }
          .invoice-container .totals-section p { margin: 5px 0; }
          .invoice-container .footer p { margin: 2px 0; }
        `}
      </style>
      <div className="invoice-container">
        <div className="header">
          <h1 style={{ fontSize: '24px', fontWeight: 'bold', margin: '0 0 5px 0' }}>{APP_NAME}</h1>
          <h2 style={{ fontSize: '20px', margin: '0' }}>{invoiceTitle}</h2>
        </div>

        <div style={{ marginBottom: '20px' }}>
          <p><strong>{TRANSLATIONS.invoiceId}:</strong> {id.slice(-8)}</p>
          <p><strong>{TRANSLATIONS.invoiceDate}:</strong> {new Date(date + 'T00:00:00').toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        </div>

        {clientSupplierSale.clientSupplierName && (
          <div style={{ marginBottom: '20px' }}>
            <h4>{TRANSLATIONS.customerInfo}:</h4>
            <p><strong>{TRANSLATIONS.clientSupplierName}:</strong> {clientSupplierSale.clientSupplierName}</p>
          </div>
        )}
        {clientTraderSale.clientTraderName && (
           <div style={{ marginBottom: '20px' }}>
            <h4>{TRANSLATIONS.customerInfo}:</h4>
            <p><strong>{TRANSLATIONS.clientTraderName}:</strong> {clientTraderSale.clientTraderName}</p>
          </div>
        )}
        {socialMediaSale.platform && (
          <div style={{ marginBottom: '20px' }}>
            <h4>{TRANSLATIONS.customerInfo}:</h4>
            <p><strong>{TRANSLATIONS.platform}:</strong> {SOCIAL_MEDIA_PLATFORM_TRANSLATIONS[socialMediaSale.platform] || socialMediaSale.platform}</p>
            <p><strong>{TRANSLATIONS.customerIdentifier}:</strong> {socialMediaSale.customerIdentifier}</p>
            {socialMediaSale.shippingAddress && <p><strong>{TRANSLATIONS.shippingAddress}:</strong> {socialMediaSale.shippingAddress}</p>}
          </div>
        )}

        <h4>{TRANSLATIONS.totalItems}:</h4>
        <table>
          <thead>
            <tr>
              <th>{TRANSLATIONS.productName}</th>
              <th>{TRANSLATIONS.quantity}</th>
              <th>{TRANSLATIONS.unitCostAtSale}</th>
              <th>{TRANSLATIONS.sellingPrice}</th>
              <th>{TRANSLATIONS.itemTotal}</th>
              <th>{TRANSLATIONS.itemProfit}</th>
            </tr>
          </thead>
          <tbody>
            {items.map((item, index) => (
              <tr key={index}>
                <td>{item.productName}</td>
                <td>{item.quantity.toLocaleString('ar-EG')}</td>
                <td>{formatCurrency(item.unitCostAtSale)}</td>
                <td>{formatCurrency(item.sellingPrice)}</td>
                <td>{formatCurrency(item.sellingPrice * item.quantity)}</td>
                <td style={{ color: item.profit >= 0 ? 'green' : 'red' }}>{formatCurrency(item.profit)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="totals-section">
          <p><strong>{TRANSLATIONS.totalCostOfGoods}:</strong> {formatCurrency(totalCostOfGoods)}</p>
          <p><strong>{TRANSLATIONS.totalRevenue}:</strong> {formatCurrency(totalRevenue)}</p>
          <p style={{ fontWeight: 'bold', color: totalProfit >= 0 ? 'green' : 'red' }}>
            <strong>{TRANSLATIONS.totalProfit}:</strong> {formatCurrency(totalProfit)}
          </p>
        </div>

        {notes && (
          <div style={{ marginTop: '20px' }}>
            <h4>{TRANSLATIONS.notes}:</h4>
            <p style={{ whiteSpace: 'pre-wrap' }}>{notes}</p>
          </div>
        )}
         <div className="footer" style={{marginTop: '30px', fontSize: '9pt', textAlign: 'center', borderTop: '1px solid #eee', paddingTop: '10px'}}>
            <p>{TRANSLATIONS.thankYouNote}</p>
            <p>{APP_NAME}</p>
            <p style={{fontSize: '8pt', color: '#555'}}>{TRANSLATIONS.appCreatorCredit} {TRANSLATIONS.appCreatorName}</p>
        </div>
      </div>
    </div>
  );
};

export default InvoiceTemplate;
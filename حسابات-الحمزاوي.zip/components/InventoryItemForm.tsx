import React, { useState, useEffect } from 'react';
import { InventoryItem } from '../types';

interface InventoryItemFormProps {
  onSubmit: (item: Omit<InventoryItem, 'id'>) => void;
  onClose: () => void;
  initialData?: InventoryItem | null;
}

const InventoryItemForm: React.FC<InventoryItemFormProps> = ({ onSubmit, onClose, initialData }) => {
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [quantity, setQuantity] = useState<number | ''>('');
  const [unitCost, setUnitCost] = useState<number | ''>('');
  const [unitPrice, setUnitPrice] = useState<number | ''>('');

  useEffect(() => {
    if (initialData) {
      setName(initialData.name);
      setSku(initialData.sku);
      setQuantity(initialData.quantity);
      setUnitCost(initialData.unitCost);
      setUnitPrice(initialData.unitPrice);
    } else {
      setName('');
      setSku('');
      setQuantity('');
      setUnitCost('');
      setUnitPrice('');
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (quantity === '' || isNaN(Number(quantity)) || 
        unitCost === '' || isNaN(Number(unitCost)) ||
        unitPrice === '' || isNaN(Number(unitPrice))) {
      alert("الرجاء إدخال قيم رقمية صحيحة للكمية، تكلفة الوحدة، وسعر البيع.");
      return;
    }
    onSubmit({ 
      name, 
      sku, 
      quantity: Number(quantity), 
      unitCost: Number(unitCost), 
      unitPrice: Number(unitPrice) 
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="itemName" className="block text-sm font-medium text-neutral-DEFAULT">اسم الصنف</label>
        <input
          type="text"
          id="itemName"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          autoFocus
        />
      </div>
      <div>
        <label htmlFor="itemSku" className="block text-sm font-medium text-neutral-DEFAULT">رمز SKU (اختياري)</label>
        <input
          type="text"
          id="itemSku"
          value={sku}
          onChange={(e) => setSku(e.target.value)}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          <label htmlFor="itemQuantity" className="block text-sm font-medium text-neutral-DEFAULT">الكمية المتوفرة</label>
          <input
            type="number"
            id="itemQuantity"
            value={quantity}
            onChange={(e) => setQuantity(e.target.value === '' ? '' : parseFloat(e.target.value))}
            required
            min="0"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="itemUnitCost" className="block text-sm font-medium text-neutral-DEFAULT">تكلفة الوحدة ($)</label>
          <input
            type="number"
            id="itemUnitCost"
            value={unitCost}
            onChange={(e) => setUnitCost(e.target.value === '' ? '' : parseFloat(e.target.value))}
            required
            min="0"
            step="0.01"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="itemUnitPrice" className="block text-sm font-medium text-neutral-DEFAULT">سعر البيع ($)</label>
          <input
            type="number"
            id="itemUnitPrice"
            value={unitPrice}
            onChange={(e) => setUnitPrice(e.target.value === '' ? '' : parseFloat(e.target.value))}
            required
            min="0"
            step="0.01"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          />
        </div>
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-neutral-DEFAULT bg-neutral-light hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
        >
          إلغاء
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark"
        >
          {initialData ? 'تحديث الصنف' : 'إضافة صنف'}
        </button>
      </div>
    </form>
  );
};

export default InventoryItemForm;

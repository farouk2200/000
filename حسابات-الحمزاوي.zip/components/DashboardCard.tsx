
import React from 'react';

interface DashboardCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  color?: string; // Tailwind background color class e.g. bg-blue-500
}

const DashboardCard: React.FC<DashboardCardProps> = ({ title, value, icon, color = 'bg-primary' }) => {
  return (
    <div className={`p-6 rounded-xl shadow-lg flex items-center space-x-4 bg-white`}>
      <div className={`p-3 rounded-full ${color} text-white`}>
        {icon}
      </div>
      <div>
        <p className="text-sm text-neutral-DEFAULT font-medium uppercase tracking-wider">{title}</p>
        <p className="text-2xl font-semibold text-neutral-dark">{value}</p>
      </div>
    </div>
  );
};

export default DashboardCard;

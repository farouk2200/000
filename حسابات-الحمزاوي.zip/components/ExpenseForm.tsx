
import React, { useState, useEffect } from 'react';
import { Expense, ExpenseCategoryKey } from '../types';
import { EXPENSE_CATEGORIES, EXPENSE_CATEGORY_TRANSLATIONS } from '../constants';
import { suggestExpenseCategory, isGeminiAvailable } from '../services/geminiService';
import LightBulbIcon from './icons/LightBulbIcon';
import LoadingSpinner from './LoadingSpinner';

interface ExpenseFormProps {
  onSubmit: (expense: Omit<Expense, 'id'>) => void;
  onClose: () => void;
  initialData?: Expense | null;
}

const ExpenseForm: React.FC<ExpenseFormProps> = ({ onSubmit, onClose, initialData }) => {
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [date, setDate] = useState('');
  const [category, setCategory] = useState<ExpenseCategoryKey>(EXPENSE_CATEGORIES[0]);
  const [isSuggesting, setIsSuggesting] = useState(false);

  const geminiEnabled = isGeminiAvailable();

  useEffect(() => {
    if (initialData) {
      setDescription(initialData.description);
      setAmount(initialData.amount);
      setDate(initialData.date);
      setCategory(initialData.category);
    } else {
      setDate(new Date().toISOString().split('T')[0]); // Default to today
    }
  }, [initialData]);

  const handleSuggestCategory = async () => {
    if (!description.trim() || !geminiEnabled) return;
    setIsSuggesting(true);
    const suggested = await suggestExpenseCategory(description);
    if (suggested && (EXPENSE_CATEGORIES as readonly string[]).includes(suggested)) {
      setCategory(suggested as ExpenseCategoryKey);
    }
    setIsSuggesting(false);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (amount === '' || isNaN(Number(amount))) {
        alert("الرجاء إدخال مبلغ صحيح.");
        return;
    }
    onSubmit({ description, amount: Number(amount), date, category });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="expenseDescription" className="block text-sm font-medium text-neutral-DEFAULT">
          الوصف
        </label>
        <input
          type="text"
          id="expenseDescription"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          autoFocus
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
            <label htmlFor="expenseAmount" className="block text-sm font-medium text-neutral-DEFAULT">
            المبلغ ($)
            </label>
            <input
            type="number"
            id="expenseAmount"
            value={amount}
            onChange={(e) => setAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
            required
            min="0.01"
            step="0.01"
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
            />
        </div>
        <div>
            <label htmlFor="expenseDate" className="block text-sm font-medium text-neutral-DEFAULT">
            التاريخ
            </label>
            <input
            type="date"
            id="expenseDate"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            required
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
            />
        </div>
      </div>
      
      <div>
        <label htmlFor="expenseCategory" className="block text-sm font-medium text-neutral-DEFAULT">
          الفئة
        </label>
        <div className="mt-1 flex rounded-md shadow-sm">
          <select
            id="expenseCategory"
            value={category}
            onChange={(e) => setCategory(e.target.value as ExpenseCategoryKey)}
            className="block w-full px-3 py-2 border border-gray-300 rounded-s-md focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          >
            {EXPENSE_CATEGORIES.map((catKey) => (
              <option key={catKey} value={catKey}>{EXPENSE_CATEGORY_TRANSLATIONS[catKey]}</option>
            ))}
          </select>
          {geminiEnabled && (
            <button
              type="button"
              onClick={handleSuggestCategory}
              disabled={isSuggesting || !description.trim()}
              title="اقتراح فئة بواسطة الذكاء الاصطناعي"
              className="inline-flex items-center px-3 py-2 border ltr:border-l-0 rtl:border-r-0 border-gray-300 rounded-e-md bg-gray-50 text-sm font-medium text-neutral-DEFAULT hover:bg-gray-100 focus:outline-none focus:ring-1 focus:ring-primary focus:border-primary disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isSuggesting ? <LoadingSpinner size="sm" /> : <LightBulbIcon className="w-5 h-5 text-yellow-500" />}
            </button>
          )}
        </div>
        {!geminiEnabled && (
             <p className="mt-1 text-xs text-neutral-DEFAULT">اقتراح الفئة بواسطة الذكاء الاصطناعي غير متاح (مفتاح API مفقود).</p>
        )}
      </div>

      <div className="flex justify-end space-x-3 pt-2">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-neutral-DEFAULT bg-neutral-light hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
        >
          إلغاء
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark"
        >
          {initialData ? 'تحديث المصروف' : 'إضافة مصروف'}
        </button>
      </div>
    </form>
  );
};

export default ExpenseForm;
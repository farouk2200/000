import React from 'react';
import NavItem from './NavItem';
import { NavItemType } from '../types';
import UserIcon from './icons/UserIcon';
import DollarSignIcon from './icons/DollarSignIcon';
import ClipboardListIcon from './icons/ClipboardListIcon';
import CogIcon from './icons/CogIcon'; 
import ArchiveBoxIcon from './icons/ArchiveBoxIcon';
import BuildingStorefrontIconOriginal from './icons/BuildingStorefrontIcon'; // Original for Our Suppliers
import ShoppingCartIcon from './icons/ShoppingCartIcon';
import GlobeAltIcon from './icons/GlobeAltIcon';
import BuildingLibraryIcon from './icons/BuildingLibraryIcon'; // For Sales to Client Suppliers
import BriefcaseIcon from './icons/BriefcaseIcon'; // For Sales to Client Traders
import { APP_NAME, TRANSLATIONS } from '../constants';


const navItems: NavItemType[] = [
  { path: '/dashboard', name: 'لوحة التحكم', icon: ClipboardListIcon },
  { path: '/employees', name: 'الموظفون', icon: UserIcon },
  { path: '/expenses', name: 'المصروفات', icon: DollarSignIcon },
  { path: '/inventory', name: 'المخزون والجرد', icon: ArchiveBoxIcon },
  { path: '/suppliers', name: 'الموردون (لنا)', icon: BuildingStorefrontIconOriginal }, // Our suppliers (we buy from)
  { path: '/sales-to-client-suppliers', name: TRANSLATIONS.salesToClientSuppliers, icon: BuildingLibraryIcon },
  { path: '/sales-to-client-traders', name: TRANSLATIONS.salesToClientTraders, icon: BriefcaseIcon },
  { path: '/retailsales', name: 'مبيعات التجزئة', icon: ShoppingCartIcon },
  { path: '/socialmediasales', name: 'مبيعات السوشيال', icon: GlobeAltIcon },
  { path: '/reports', name: 'تقارير الذكاء الاصطناعي', icon: CogIcon },
];

const Sidebar: React.FC = () => {
  const appNameParts = APP_NAME.split(' ');
  const firstWord = appNameParts[0];
  const restOfName = appNameParts.slice(1).join(' ');

  return (
    <div className="w-72 bg-primary-dark text-white flex flex-col"> {/* Increased width for longer names */}
      <div className="p-6 text-2xl font-bold border-b border-primary-light/30">
        {firstWord} {restOfName && <span className="font-normal">{restOfName}</span>}
      </div>
      <nav className="flex-1 p-4 space-y-1 overflow-y-auto"> {/* Reduced space-y for more items */}
        {navItems.map((item) => (
          <NavItem key={item.path} item={item} />
        ))}
      </nav>
      <div className="p-4 border-t border-primary-light/30 text-center text-xs text-primary-light">
        <p>© {new Date().getFullYear()} {APP_NAME}</p>
        <p>{TRANSLATIONS.appCreatorCredit} {TRANSLATIONS.appCreatorName}</p>
      </div>
    </div>
  );
};

export default Sidebar;

import React from 'react';

interface PageTitleProps {
  title: string;
  children?: React.ReactNode; // For action buttons etc.
}

const PageTitle: React.FC<PageTitleProps> = ({ title, children }) => {
  return (
    <div className="mb-6 flex flex-col sm:flex-row justify-between items-center">
      <h2 className="text-3xl font-bold text-neutral-dark mb-2 sm:mb-0">{title}</h2>
      {children && <div className="flex space-x-2">{children}</div>}
    </div>
  );
};

export default PageTitle;

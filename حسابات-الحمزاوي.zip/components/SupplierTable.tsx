import React from 'react';
import { Supplier } from '../types';

interface SupplierTableProps {
  suppliers: Supplier[];
  onEdit?: (supplier: Supplier) => void;
  onDelete?: (supplierId: string) => void;
}

const SupplierTable: React.FC<SupplierTableProps> = ({ suppliers, onEdit, onDelete }) => {
  if (suppliers.length === 0) {
    return <p className="text-neutral-DEFAULT text-center py-8">لا يوجد موردون مسجلون. أضف البعض للبدء.</p>;
  }

  return (
    <div className="overflow-x-auto bg-white shadow-md rounded-lg">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">اسم المورد</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الشخص المسؤول</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">البريد الإلكتروني</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الهاتف</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">العنوان</th>
            {(onEdit || onDelete) && <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الإجراءات</th>}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {suppliers.map((supplier) => (
            <tr key={supplier.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-neutral-dark">{supplier.name}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{supplier.contactPerson || '-'}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{supplier.email || '-'}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{supplier.phone || '-'}</td>
              <td className="px-6 py-4 whitespace-normal text-sm text-neutral-DEFAULT">{supplier.address || '-'}</td>
              {(onEdit || onDelete) && (
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  {onEdit && (
                    <button onClick={() => onEdit(supplier)} className="text-primary hover:text-primary-dark transition-colors">تعديل</button>
                  )}
                  {onDelete && (
                    <button onClick={() => onDelete(supplier.id)} className="text-red-600 hover:text-red-800 transition-colors">حذف</button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default SupplierTable;

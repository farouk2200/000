
import React from 'react';

const LightBulbIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 18v-5.25m0 0a6.01 6.01 0 001.5-.189m-1.5.189a6.01 6.01 0 01-1.5-.189m3.75 7.478a12.06 12.06 0 01-4.5 0m3.75 2.354a15.055 15.055 0 01-3 0M10.5 18.75h3M9 12.75h6m-6 3h6M3.75 6.75h16.5M3.75 9.75h16.5M5.25 12.75a.75.75 0 01-.75-.75V8.25a.75.75 0 01.75-.75h13.5a.75.75 0 01.75.75v3.75a.75.75 0 01-.75.75H5.25z" />
  </svg>
);
export default LightBulbIcon;

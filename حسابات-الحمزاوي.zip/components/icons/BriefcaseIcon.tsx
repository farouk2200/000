import React from 'react';

// Heroicon: BriefcaseIcon
const BriefcaseIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.155V18a2.25 2.25 0 01-2.25 2.25h-12A2.25 2.25 0 013.75 18V14.155m16.5 0c.075.216.151.429.227.641A11.469 11.469 0 0112 16.5c-2.635 0-5.093-.919-7.027-2.468.076-.212.152-.425.227-.641m16.5 0A2.25 2.25 0 0018 11.845H6a2.25 2.25 0 00-2.25 2.31m16.5 0h-16.5m16.5 0A9 9 0 0012 5.25 9 9 0 003.75 14.155M12 10.5h.008v.008H12V10.5z" />
  </svg>
);
export default BriefcaseIcon;

import React, { useState, useEffect } from 'react';
import { Supplier } from '../types';

interface SupplierFormProps {
  onSubmit: (supplier: Omit<Supplier, 'id'>) => void;
  onClose: () => void;
  initialData?: Supplier | null;
}

const SupplierForm: React.FC<SupplierFormProps> = ({ onSubmit, onClose, initialData }) => {
  const [name, setName] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');

  useEffect(() => {
    if (initialData) {
      setName(initialData.name);
      setContactPerson(initialData.contactPerson);
      setEmail(initialData.email);
      setPhone(initialData.phone);
      setAddress(initialData.address);
    } else {
      setName('');
      setContactPerson('');
      setEmail('');
      setPhone('');
      setAddress('');
    }
  }, [initialData]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({ name, contactPerson, email, phone, address });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label htmlFor="supplierName" className="block text-sm font-medium text-neutral-DEFAULT">اسم المورد/التاجر</label>
        <input
          type="text"
          id="supplierName"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          autoFocus
        />
      </div>
      <div>
        <label htmlFor="contactPerson" className="block text-sm font-medium text-neutral-DEFAULT">الشخص المسؤول (اختياري)</label>
        <input
          type="text"
          id="contactPerson"
          value={contactPerson}
          onChange={(e) => setContactPerson(e.target.value)}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
        />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label htmlFor="supplierEmail" className="block text-sm font-medium text-neutral-DEFAULT">البريد الإلكتروني (اختياري)</label>
          <input
            type="email"
            id="supplierEmail"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          />
        </div>
        <div>
          <label htmlFor="supplierPhone" className="block text-sm font-medium text-neutral-DEFAULT">رقم الهاتف (اختياري)</label>
          <input
            type="tel"
            id="supplierPhone"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
          />
        </div>
      </div>
      <div>
        <label htmlFor="supplierAddress" className="block text-sm font-medium text-neutral-DEFAULT">العنوان (اختياري)</label>
        <textarea
          id="supplierAddress"
          rows={3}
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
        />
      </div>
      <div className="flex justify-end space-x-3 pt-2">
        <button
          type="button"
          onClick={onClose}
          className="px-4 py-2 text-sm font-medium text-neutral-DEFAULT bg-neutral-light hover:bg-gray-200 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-400"
        >
          إلغاء
        </button>
        <button
          type="submit"
          className="px-4 py-2 text-sm font-medium text-white bg-primary hover:bg-primary-dark rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-dark"
        >
          {initialData ? 'تحديث المورد' : 'إضافة مورد'}
        </button>
      </div>
    </form>
  );
};

export default SupplierForm;


import React from 'react';
import { Employee } from '../types';
import UserIcon from './icons/UserIcon'; // Example icon

interface EmployeeTableProps {
  employees: Employee[];
  onEdit?: (employee: Employee) => void; // Optional edit functionality
  onDelete?: (employeeId: string) => void; // Optional delete functionality
}

const EmployeeTable: React.FC<EmployeeTableProps> = ({ employees, onEdit, onDelete }) => {
  if (employees.length === 0) {
    return <p className="text-neutral-DEFAULT text-center py-8">لم يتم العثور على موظفين. أضف البعض للبدء!</p>;
  }

  return (
    <div className="overflow-x-auto bg-white shadow-md rounded-lg">
      <table className="min-w-full divide-y divide-gray-200">
        <thead className="bg-gray-50">
          <tr>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الاسم</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">المنصب</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الراتب الشهري</th>
            <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">تاريخ التعيين</th>
            {(onEdit || onDelete) && <th scope="col" className="px-6 py-3 text-start text-xs font-medium text-neutral-DEFAULT uppercase tracking-wider">الإجراءات</th>}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {employees.map((employee) => (
            <tr key={employee.id} className="hover:bg-gray-50">
              <td className="px-6 py-4 whitespace-nowrap">
                <div className="flex items-center">
                  <div className="flex-shrink-0 h-10 w-10">
                    <div className="w-10 h-10 rounded-full bg-primary-light flex items-center justify-center text-white">
                        <UserIcon className="w-6 h-6" />
                    </div>
                  </div>
                  <div className="ms-4">
                    <div className="text-sm font-medium text-neutral-dark">{employee.name}</div>
                  </div>
                </div>
              </td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{employee.role}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">${employee.monthlySalary.toLocaleString('ar-EG', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</td>
              <td className="px-6 py-4 whitespace-nowrap text-sm text-neutral-DEFAULT">{new Date(employee.hireDate + 'T00:00:00').toLocaleDateString('ar-EG')}</td>
              {(onEdit || onDelete) && (
                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                  {onEdit && (
                    <button onClick={() => onEdit(employee)} className="text-primary hover:text-primary-dark transition-colors">تعديل</button>
                  )}
                  {onDelete && (
                    <button onClick={() => onDelete(employee.id)} className="text-red-600 hover:text-red-800 transition-colors">حذف</button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeTable;
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_TEXT_MODEL, EXPENSE_CATEGORIES } from '../constants';
import { Employee, Expense, InventoryItem, Supplier, RetailSale, SocialMediaSale, SaleToClientSupplier, SaleToClientTrader, BaseSaleOrder } from '../types';

const API_KEY = process.env.API_KEY;

let ai: GoogleGenAI | null = null;
if (API_KEY) {
  ai = new GoogleGenAI({ apiKey: API_KEY });
} else {
  console.warn("Gemini API Key not found. AI features will be disabled.");
}

export const isGeminiAvailable = (): boolean => !!ai;

export const suggestExpenseCategory = async (description: string): Promise<string | null> => {
  if (!ai) return null;

  const prompt = `Suggest an expense category for the following description: "${description}".
Choose from this list: ${EXPENSE_CATEGORIES.join(', ')}.
Return only the category name. If unsure, return "Other".`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: prompt,
    });
    const category = response.text.trim();
    if (EXPENSE_CATEGORIES.includes(category as any)) {
        return category;
    }
    return "Other";
  } catch (error) {
    console.error("Error suggesting expense category:", error);
    return "Other";
  }
};

const formatSalesForContext = (sales: BaseSaleOrder[], saleType: string): string => {
  if (sales.length === 0) return `No ${saleType} data available.`;
  return sales.map(s => 
    `- Sale ID: ${s.id.slice(-6)}, Date: ${s.date}, Items: ${s.items.length}, Cost: $${s.totalCostOfGoods.toFixed(2)}, Revenue: $${s.totalRevenue.toFixed(2)}, Profit: $${s.totalProfit.toFixed(2)}`
    + ((s as SaleToClientSupplier).clientSupplierName ? `, Client Supplier: ${(s as SaleToClientSupplier).clientSupplierName}` : '')
    + ((s as SaleToClientTrader).clientTraderName ? `, Client Trader: ${(s as SaleToClientTrader).clientTraderName}` : '')
    + ((s as SocialMediaSale).platform ? `, Platform: ${(s as SocialMediaSale).platform}, Customer: ${(s as SocialMediaSale).customerIdentifier}` : '')
  ).join('\n');
};


export const getFinancialInsights = async (
  question: string,
  employees: Employee[],
  expenses: Expense[],
  inventoryItems: InventoryItem[],
  suppliers: Supplier[], // Our suppliers
  retailSales: RetailSale[],
  socialMediaSales: SocialMediaSale[],
  salesToClientSuppliers: SaleToClientSupplier[],
  salesToClientTraders: SaleToClientTrader[]
): Promise<string | null> => {
  if (!ai) return null;

  const currentDate = new Date().toISOString().split('T')[0];

  const employeesContext = employees.length > 0 
    ? employees.map(e => `- ${e.name} (Role: ${e.role}, Salary: $${e.monthlySalary.toFixed(2)}/month, Hired: ${e.hireDate})`).join('\n')
    : "No employee data available.";

  const expensesContext = expenses.length > 0
    ? expenses.map(ex => `- ${ex.description} (Amount: $${ex.amount.toFixed(2)}, Category: ${ex.category}, Date: ${ex.date})`).join('\n')
    : "No expense data available.";

  const inventoryContext = inventoryItems.length > 0
    ? inventoryItems.map(item => `- ${item.name} (SKU: ${item.sku || 'N/A'}, Qty: ${item.quantity}, Our Cost: $${item.unitCost.toFixed(2)}, General Price: $${item.unitPrice.toFixed(2)})`).join('\n')
    : "No inventory data available.";

  const suppliersContext = suppliers.length > 0 // Our suppliers context
    ? suppliers.map(s => `- ${s.name} (Contact: ${s.contactPerson || 'N/A'}, Email: ${s.email || 'N/A'}, Phone: ${s.phone || 'N/A'})`).join('\n')
    : "No data for our suppliers available.";
  
  const retailSalesContext = formatSalesForContext(retailSales, "Retail Sales");
  const socialMediaSalesContext = formatSalesForContext(socialMediaSales, "Social Media Sales");
  const salesToClientSuppliersContext = formatSalesForContext(salesToClientSuppliers, "Sales to Client Suppliers");
  const salesToClientTradersContext = formatSalesForContext(salesToClientTraders, "Sales to Client Traders");


  const prompt = `
You are a helpful financial assistant for a small factory.
Analyze the following data and answer the user's question concisely.
If the data is insufficient to answer, please state that. Do not make up information.
Provide amounts in USD ($). "Our Cost" refers to the factory's cost for an item.

Current Date: ${currentDate}

Employee Data (${employees.length} total):
${employeesContext}

Expense Data (${expenses.length} total):
${expensesContext}

Inventory Data (Our Stock - ${inventoryItems.length} total items):
${inventoryContext}

Our Suppliers Data (Entities we buy from - ${suppliers.length} total):
${suppliersContext}

Retail Sales Data (${retailSales.length} total sales):
${retailSalesContext}

Social Media Sales Data (${socialMediaSales.length} total sales):
${socialMediaSalesContext}

Sales to Client Suppliers Data (Our sales to distributor-type clients - ${salesToClientSuppliers.length} total sales):
${salesToClientSuppliersContext}

Sales to Client Traders Data (Our sales to trader-type clients - ${salesToClientTraders.length} total sales):
${salesToClientTradersContext}

---
User Question: ${question}
---
Answer:
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: prompt,
      config: {
        temperature: 0.3,
      }
    });
    return response.text.trim();
  } catch (error) {
    console.error("Error getting financial insights:", error);
    return "عذراً، لقد واجهت خطأ أثناء معالجة طلبك.";
  }
};
